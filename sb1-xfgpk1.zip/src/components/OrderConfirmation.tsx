import React from 'react';
import { UserType } from '../App';
import { CheckCircle, MapPin, Calendar, Clock } from 'lucide-react';

type OrderConfirmationProps = {
  user: UserType | null;
};

export default function OrderConfirmation({ user }: OrderConfirmationProps) {
  const orderNumber = Math.random().toString(36).substr(2, 9).toUpperCase();

  return (
    <div className="bg-white rounded-lg shadow-xl p-8 max-w-md mx-auto">
      <div className="flex flex-col items-center justify-center text-center">
        <div className="mb-4">
          <CheckCircle className="h-16 w-16 text-green-500" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Booking Confirmed!</h2>
        <p className="text-gray-600 mb-6">Your service has been scheduled successfully.</p>
        
        <div className="bg-gray-50 w-full p-6 rounded-lg mb-6">
          <p className="text-sm text-gray-500 mb-2">Order Number</p>
          <p className="text-lg font-mono font-bold text-gray-800">{orderNumber}</p>
        </div>

        <div className="w-full space-y-4">
          <div className="flex items-start space-x-3">
            <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
            <div className="flex-1 text-left">
              <p className="text-sm text-gray-500">Service Location</p>
              <p className="text-gray-800">{user?.address}</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <Calendar className="h-5 w-5 text-gray-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-gray-500">Appointment Date</p>
              <p className="text-gray-800">March 15, 2024</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <Clock className="h-5 w-5 text-gray-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-gray-500">Time Slot</p>
              <p className="text-gray-800">02:00 PM - 03:00 PM</p>
            </div>
          </div>
        </div>

        <div className="mt-8 w-full">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
            <p className="font-medium mb-1">What's Next?</p>
            <ul className="list-disc list-inside space-y-1 text-blue-700">
              <li>Our technician will arrive at the scheduled time</li>
              <li>You'll receive an SMS 30 minutes before arrival</li>
              <li>Payment can be made after service completion</li>
            </ul>
          </div>
        </div>

        <button
          onClick={() => window.location.reload()}
          className="mt-8 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Book Another Service
        </button>
      </div>
    </div>
  );
}