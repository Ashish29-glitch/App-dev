import React, { useState } from 'react';
import { FileCheck, AlertCircle } from 'lucide-react';
import { UserType } from '../App';

type IdVerificationProps = {
  user: UserType | null;
  onComplete: (user: UserType) => void;
};

export default function IdVerification({ user, onComplete }: IdVerificationProps) {
  const [govIdType, setGovIdType] = useState<'aadhar' | 'pan' | 'driving' | 'voter'>('aadhar');
  const [govIdNumber, setGovIdNumber] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const idPatterns = {
      aadhar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
      driving: /^[A-Z]{2}[0-9]{13}$/,
      voter: /^[A-Z]{3}[0-9]{7}$/
    };

    if (!idPatterns[govIdType].test(govIdNumber)) {
      setError('Invalid ID format');
      return;
    }

    onComplete({
      ...user,
      govId: { type: govIdType, number: govIdNumber }
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-xl p-8 max-w-md mx-auto">
      <div className="flex items-center justify-center mb-6">
        <FileCheck className="h-12 w-12 text-indigo-600" />
      </div>
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Verify Your Identity</h2>
      <p className="text-center text-gray-600 mb-8">Please provide a valid government ID</p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Government ID Type
          </label>
          <select
            value={govIdType}
            onChange={(e) => setGovIdType(e.target.value as any)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="aadhar">Aadhaar Card</option>
            <option value="pan">PAN Card</option>
            <option value="driving">Driving License</option>
            <option value="voter">Voter ID</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            ID Number
          </label>
          <input
            type="text"
            value={govIdNumber}
            onChange={(e) => setGovIdNumber(e.target.value.toUpperCase())}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter your ID number"
          />
        </div>

        {error && (
          <div className="flex items-center space-x-2 text-red-600">
            <AlertCircle className="h-5 w-5" />
            <span className="text-sm">{error}</span>
          </div>
        )}

        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="text-sm font-medium text-blue-800 mb-2">ID Format Guidelines:</h3>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Aadhaar: 12 digits number</li>
            <li>• PAN: 5 letters + 4 numbers + 1 letter</li>
            <li>• Driving License: 2 letters + 13 numbers</li>
            <li>• Voter ID: 3 letters + 7 numbers</li>
          </ul>
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Verify Identity
        </button>
      </form>
    </div>
  );
}