import React, { useState } from 'react';
import { UserType } from '../App';
import { User, MapPin, Phone, Building } from 'lucide-react';

type ProfileProps = {
  user: UserType | null;
  onComplete: (user: UserType) => void;
};

const DISTRICTS = ['Cuttack', 'Bhubaneswar'];

export default function Profile({ user, onComplete }: ProfileProps) {
  const [name, setName] = useState(user?.name || '');
  const [district, setDistrict] = useState('');
  const [address, setAddress] = useState(user?.address || '');
  const [landmark, setLandmark] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    const fullAddress = `${address}, ${landmark}, ${district}, Odisha`;
    
    onComplete({
      ...user,
      name,
      address: fullAddress,
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-xl p-8 max-w-md mx-auto">
      <div className="flex items-center justify-center mb-6">
        <User className="h-12 w-12 text-orange-600" />
      </div>
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">प्रोफ़ाइल पूरा करें</h2>
      <p className="text-center text-gray-600 mb-8">Complete Your Profile</p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            पूरा नाम / Full Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
            placeholder="Enter your full name"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            जिला / District
          </label>
          <select
            value={district}
            onChange={(e) => setDistrict(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
            required
          >
            <option value="">Select District</option>
            {DISTRICTS.map(dist => (
              <option key={dist} value={dist}>{dist}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            पता / Address
          </label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
            placeholder="Street address, House/Apartment number"
            rows={3}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            लैंडमार्क / Landmark
          </label>
          <input
            type="text"
            value={landmark}
            onChange={(e) => setLandmark(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
            placeholder="Nearby landmark"
            required
          />
        </div>

        <div className="bg-orange-50 p-4 rounded-lg">
          <p className="text-sm text-orange-800">
            Currently serving only in Cuttack and Bhubaneswar districts of Odisha
          </p>
        </div>

        <button
          type="submit"
          className="w-full bg-orange-600 text-white py-2 px-4 rounded-md hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"
        >
          जारी रखें / Continue
        </button>
      </form>
    </div>
  );
}