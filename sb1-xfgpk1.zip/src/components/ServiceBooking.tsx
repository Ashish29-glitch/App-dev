import React, { useState } from 'react';
import { UserType } from '../App';
import { Calendar, Clock, AlertTriangle, Wrench } from 'lucide-react';

type ServiceBookingProps = {
  user: UserType | null;
  onComplete: () => void;
};

const timeSlots = [
  '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
  '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
];

const issues = [
  { id: 'power', label: 'Power Failure', price: 50 },
  { id: 'short', label: 'Short Circuit', price: 75 },
  { id: 'wiring', label: 'Wiring Issue', price: 100 },
  { id: 'appliance', label: 'Appliance Installation', price: 120 },
  { id: 'fan', label: 'Fan/Light Installation', price: 60 },
  { id: 'other', label: 'Other Electrical Issues', price: 80 }
];

export default function ServiceBooking({ user, onComplete }: ServiceBookingProps) {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [issue, setIssue] = useState('');
  const [description, setDescription] = useState('');
  const [urgency, setUrgency] = useState('normal');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete();
  };

  const selectedIssue = issues.find(i => i.id === issue);
  const urgencyFee = urgency === 'urgent' ? 30 : 0;
  const totalPrice = selectedIssue ? selectedIssue.price + urgencyFee : 0;

  return (
    <div className="bg-white rounded-lg shadow-xl p-8 max-w-2xl mx-auto">
      <div className="flex items-center justify-center mb-6">
        <Wrench className="h-12 w-12 text-indigo-600" />
      </div>
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Book Electrical Service</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                required
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
            <div className="relative">
              <Clock className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <select
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                required
              >
                <option value="">Select time</option>
                {timeSlots.map(slot => (
                  <option key={slot} value={slot}>{slot}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Issue Type</label>
          <select
            value={issue}
            onChange={(e) => setIssue(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
            required
          >
            <option value="">Select issue</option>
            {issues.map(i => (
              <option key={i.id} value={i.id}>{i.label} (${i.price})</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Please describe your electrical issue in detail..."
            rows={4}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Urgency Level</label>
          <div className="flex space-x-4">
            <label className="flex items-center">
              <input
                type="radio"
                value="normal"
                checked={urgency === 'normal'}
                onChange={(e) => setUrgency(e.target.value)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="ml-2 text-sm text-gray-600">Normal</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                value="urgent"
                checked={urgency === 'urgent'}
                onChange={(e) => setUrgency(e.target.value)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="ml-2 text-sm text-gray-600">Urgent (+$30)</span>
            </label>
          </div>
        </div>

        {totalPrice > 0 && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800">Price Breakdown</h3>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between">
                <span>Service Fee</span>
                <span>${selectedIssue?.price}</span>
              </div>
              {urgencyFee > 0 && (
                <div className="flex justify-between text-orange-600">
                  <span>Urgency Fee</span>
                  <span>+${urgencyFee}</span>
                </div>
              )}
              <div className="flex justify-between font-bold pt-2 border-t">
                <span>Total</span>
                <span>${totalPrice}</span>
              </div>
            </div>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Confirm Booking
        </button>
      </form>
    </div>
  );
}