import React, { useState } from 'react';
import { Shield, User, Zap, Clock, CheckCircle, FileCheck } from 'lucide-react';
import Login from './components/Login';
import IdVerification from './components/IdVerification';
import Profile from './components/Profile';
import ServiceBooking from './components/ServiceBooking';
import OrderConfirmation from './components/OrderConfirmation';

export type UserType = {
  email: string;
  phone: string;
  govId?: {
    type: 'aadhar' | 'pan' | 'driving' | 'voter';
    number: string;
  };
  name?: string;
  address?: string;
};

function App() {
  const [step, setStep] = useState<'login' | 'verify' | 'profile' | 'booking' | 'confirmation'>('login');
  const [user, setUser] = useState<UserType | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-indigo-600" />
              <span className="text-xl font-bold text-gray-800">ElectroFix</span>
            </div>
            {user && (
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-gray-600" />
                <span className="text-gray-600">{user.name || user.email}</span>
              </div>
            )}
          </div>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {step === 'login' && <Login onLogin={(userData) => { setUser(userData); setStep('verify'); }} />}
        {step === 'verify' && <IdVerification user={user} onComplete={(userData) => { setUser(userData); setStep('profile'); }} />}
        {step === 'profile' && <Profile user={user} onComplete={(userData) => { setUser(userData); setStep('booking'); }} />}
        {step === 'booking' && <ServiceBooking user={user} onComplete={() => setStep('confirmation')} />}
        {step === 'confirmation' && <OrderConfirmation user={user} />}

        <div className="mt-8">
          <div className="flex justify-center items-center space-x-8">
            <Step icon={Shield} text="Login" active={step === 'login'} completed={step !== 'login'} />
            <Step icon={FileCheck} text="Verify ID" active={step === 'verify'} completed={['profile', 'booking', 'confirmation'].includes(step)} />
            <Step icon={User} text="Profile" active={step === 'profile'} completed={['booking', 'confirmation'].includes(step)} />
            <Step icon={Clock} text="Book Service" active={step === 'booking'} completed={step === 'confirmation'} />
            <Step icon={CheckCircle} text="Confirmation" active={step === 'confirmation'} completed={false} />
          </div>
        </div>
      </main>
    </div>
  );
}

function Step({ icon: Icon, text, active, completed }: { icon: any, text: string, active: boolean, completed: boolean }) {
  return (
    <div className={`flex flex-col items-center ${active ? 'text-indigo-600' : completed ? 'text-green-600' : 'text-gray-400'}`}>
      <div className={`p-3 rounded-full ${active ? 'bg-indigo-100' : completed ? 'bg-green-100' : 'bg-gray-100'}`}>
        <Icon className="h-6 w-6" />
      </div>
      <span className="mt-2 text-sm font-medium">{text}</span>
    </div>
  );
}

export default App;